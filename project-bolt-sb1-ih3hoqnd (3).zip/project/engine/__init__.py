"""Snowflake platform templating engine."""
